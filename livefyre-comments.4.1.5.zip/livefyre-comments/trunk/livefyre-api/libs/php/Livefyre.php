<?php
include( dirname(__FILE__) . '/Domain.php' );
?>